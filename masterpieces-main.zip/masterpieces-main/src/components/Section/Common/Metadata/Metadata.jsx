// metadata.js
export const Metadata = {
    title: "Masterpieces Al Qudra Trading",
    description: "Masterpieces Al Qudra Trading",
    icons: {
      icon: ["/favicon.ico?v=4"],
      apple: ["/favicon.ico?v=4"],
      shortcut: ["/favicon.ico"],
    },
  };
  