export { default } from "./ErrorSection";
