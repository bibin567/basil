export { default } from "./Fact";
